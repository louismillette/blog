$(document).ready(function() {
  $.fn.dataTable.moment( 'MMM D, YYYY' );
  $('#Nominal-Weekly-Distribution').DataTable();
  // $('#Real-Weekly-Distribution').DataTable();
} );